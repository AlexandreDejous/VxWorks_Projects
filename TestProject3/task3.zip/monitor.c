#include <taskLib.h>
#include <stdio.h>
#include <semLib.h>
#include <stdlib.h>
#include <unistd.h>

#include "t3_header.h"


void main(int argc, char *argv[]){
	
	init_shm();
	int i;
	printf("--- Monitor started ---\n");
	while (1){
		printf("-----------------------\n");
		for (i = 0; i <50; i++){
		    if (ptr->companies[i].name[0]!=0){
		      printf("%s:   %d\n",ptr->companies[i].name,ptr->companies[i].work_done);
		    }
		}
		sleep(1);
	}
	

}


